<footer class="main-footer">
	
	<strong>Copyright &copy; 2019 <a href="http://www.armonicolat.com" target="_blank">ARMONICO S.A. de C.V.</a>.</strong>

	Todos los derechos reservados.


</footer>