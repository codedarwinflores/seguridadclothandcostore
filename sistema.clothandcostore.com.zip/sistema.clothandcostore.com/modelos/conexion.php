<?php

class Conexion{

	static public function conectar(){

		$link = new PDO("mysql:host=localhost;dbname=prioria1_sistema_facturacion",
			            "prioria1_sistema_facturacion",
			            "sistema_facturacion11!!");

		$link->exec("set names utf8");

		return $link;

	}

}